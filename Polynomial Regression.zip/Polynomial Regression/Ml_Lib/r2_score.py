import numpy as np
class r2score:
    def __new__(cls,h,y):
    
        e1 = np.power((h-y),2).sum()
        e2 = np.power(y-np.mean(y),2).sum()
        return 1 - (e1/e2)